-- Create Database
create database OnlineBookstore;

-- Create Tables
create table Books (
	Book_ID int primary key,
	Title varchar(100),
	Author varchar(100),
	Genre varchar(50),
	Published_Year int, 
	Price numeric(10, 2),
	Stock int
);

create table Customers(
	Customer_ID int primary key,
	Name varchar(100),
	Email varchar(100),
	Phone varchar(15),
	City varchar(50),
	Country varchar(150)
);

create table Orders(
	Order_ID int primary key,
	Customer_ID int references Customers(Customer_ID),
	Book_ID int references Books(Book_ID),
	Order_Date date,
	Quantity int,
	Total_Amount numeric(10,2)
);

SELECT * FROM Books;
SELECT * FROM Customers;
SELECT * FROM Orders;

-- Import Data into Books Table
copy Books(Book_ID, Title, Author, Genre, Published_Year, Price, Stock)
from 'D:\Books.csv'
csv header;

-- Import Data into Customers Table
copy Customers(Customer_ID, Name, Email, Phone, City, Country)
from 'D:\Customers.csv'
csv header;

-- Import Data into Orders Table
copy Orders(Order_ID, Customer_ID, Book_ID, Order_Date, Quantity, Total_Amount)
from 'D:\Orders.csv'
csv header;


-- Check for missing Data 
select * from Customers 
where Email is Null;

select * from Books 
where Price is Null
or Stock is Null;


-- Basic Queries 

-- 1) Retrieve all books in the "Fiction" genre
select * from Books
where Genre = 'Fiction';

-- 2) Find Books published after the year 1950
select * from Books
where Published_Year > 1950;

-- 3) List all customers from the Canada
select * from Customers
where Country = 'Canada';

-- 4) Show orders placed in November 2023
select * from Orders
where Order_date between '2023-11-01' and '2023-11-30';

-- 5) Retrieve the total stock of books available
select sum(Stock) as Total_Stock
from Books;

-- 6) Find the details of the most expensive book
select * from Books
Order by Price Desc
limit 1;

-- 7) Show all the customers who ordered more than 1 quantity of book
select * from Orders
where Quantity > 1;

-- 8) Retrieve all orders where the total amount exceeds $20
select * from Orders
where Total_Amount > 20;

-- 9) List all genres available in Books table
select distinct Genre from Books;

-- 10) Find the book with the lowest stock
select * from Books
order by stock asc
limit 1;

-- 11) Calculate the total revenue generated from all orders
select sum(Total_Amount) as Revenue from Orders;


-- Advance Queries 

-- 1) Retrieve the total number of books sold for each genre
select * from Orders
select b.Genre, sum(o.Quantity) as Total_BooksSold
from Orders o 
join Books b on o.Book_ID = b.Book_ID
group by b.Genre;

-- 2) Find the average price of books in the "Fantasy" genre
select avg(Price) as Avg_Price
from Books
where Genre = 'Fantasy'

-- 3) List customers who have placed at least 2 orders:
select o.Customer_ID, c.name, count(o.Order_ID) as Order_count 
from Orders o
join Customers c on o.Customer_ID = c.Customer_ID 
group by o.Customer_ID, c.name
having count(Order_ID) >= 2;

-- 4) Find the most frequently ordered book
select o.Book_ID, b.Title, count(o.Order_ID) as Order_count
from Orders o
join Books b on o.Book_ID = b.Book_ID
group by o.Book_ID, b.title
order by Order_count desc
limit 1;

-- 5) Show the top 3 most expensive books of 'Fantasy' Genre 
select * from Books
where Genre = 'Fantasy'
order by Price Desc
limit 3;

-- 6) Retrieve the total quantity of books sold by each author
select b.Author, sum(o.Quantity) as Total_Books_Sold 
from Orders o 
join Books b on o.Book_ID = b.Book_ID
group by b.Author;

-- 7) List the cities where customers who spent over $30 are located
select distinct c.City, Total_Amount
from Orders o
join Customers c on o.Customer_ID = c.Customer_ID
where o.Total_Amount > 30;

-- 8) Find the customer who spent the most on orders
select c.Customer_ID, c.Name, sum(o.Total_Amount) as Total_Spent
from Orders o
join Customers c on o.Customer_ID = c.Customer_ID
group by c.Customer_ID, c.Name
order by Total_Spent desc

-- 9) Calculate the stock remaining after fulfilling all orders
select b.Book_ID, b.title, b.stock, coalesce(sum(quantity), 0) as Order_quantity, 
	b.stock - coalesce(sum(o.Quantity), 0) as Remaining_quantity
from Books b
left join orders o on b.Book_ID = o.Book_ID
group by b.Book_ID;


-- Useful Queries

-- 1) Top 5 Selling Books
select b.Title, sum(o.Quantity) as Total_sold
from Orders o
join Books b on o.Book_ID = b.Book_ID
group by b.Title
Order by Total_sold desc 
Limit 5;

-- 2) Monthly Revenue
select DATE_TRUNC('month', Order_Date) as Month,
sum(Total_Amount) as Revenue
from orders
group by Month
Order by Month;

-- 3) Top 5 customers by Spend
select c.Name, sum(o.Total_Amount) as Total_Spent 
from Orders o
join Customers c on o.Customer_ID = c.Customer_ID
group by c.Name
order by Total_Spent desc 
limit 5;

-- 4) Total Quantity sold by Genre
select b.Genre, sum(o.Quantity) as Total_Sold 
from Orders o
join Books b on o.Book_ID = b.Book_ID
group by Genre;

-- 5) Low stock books 
select Title, Stock
from Books
order by Stock Asc 
Limit 5;
	
